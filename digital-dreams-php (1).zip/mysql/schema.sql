-- CreateTable
CREATE TABLE `users` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(191) NULL,
    `email` VARCHAR(191) NULL,
    `password` VARCHAR(191) NULL,
    `role` VARCHAR(191) NULL DEFAULT 'customer',
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `phone` VARCHAR(191) NULL,
    `company` VARCHAR(191) NULL,
    `avatar` TEXT NULL,
    `googleId` VARCHAR(191) NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    UNIQUE INDEX `users_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `roles` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(191) NULL,
    `permissions` JSON NULL,
    `createdAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `customers` (
    `id` VARCHAR(64) NOT NULL,
    `userId` VARCHAR(191) NULL,
    `name` VARCHAR(191) NULL,
    `email` VARCHAR(191) NULL,
    `phone` VARCHAR(191) NULL,
    `company` VARCHAR(191) NULL,
    `totalOrders` INTEGER NULL DEFAULT 0,
    `totalSpent` DOUBLE NULL DEFAULT 0,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    INDEX `customers_email_idx`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `packages` (
    `id` VARCHAR(64) NOT NULL,
    `slug` VARCHAR(191) NULL,
    `name` VARCHAR(191) NULL,
    `price` DOUBLE NULL,
    `contactSales` BOOLEAN NULL DEFAULT false,
    `description` TEXT NULL,
    `badge` VARCHAR(191) NULL,
    `popular` BOOLEAN NULL DEFAULT false,
    `sortOrder` INTEGER NULL DEFAULT 0,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `features` JSON NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `package_features` (
    `id` VARCHAR(64) NOT NULL,
    `packageId` VARCHAR(191) NULL,
    `feature` TEXT NULL,
    `sortOrder` INTEGER NULL DEFAULT 0,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    INDEX `package_features_packageId_idx`(`packageId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `addons` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(191) NULL,
    `description` TEXT NULL,
    `price` DOUBLE NULL,
    `category` VARCHAR(191) NULL,
    `icon` VARCHAR(191) NULL,
    `image` TEXT NULL,
    `sortOrder` INTEGER NULL DEFAULT 0,
    `popular` BOOLEAN NULL DEFAULT false,
    `featured` BOOLEAN NULL DEFAULT false,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `orders` (
    `id` VARCHAR(64) NOT NULL,
    `orderNumber` VARCHAR(191) NULL,
    `packageId` VARCHAR(191) NULL,
    `addonIds` JSON NULL,
    `customerName` VARCHAR(191) NULL,
    `customerEmail` VARCHAR(191) NULL,
    `customerPhone` VARCHAR(191) NULL,
    `customerCompany` VARCHAR(191) NULL,
    `projectDetails` TEXT NULL,
    `websiteUrl` VARCHAR(191) NULL,
    `serviceType` VARCHAR(191) NULL,
    `pricing` JSON NULL,
    `status` VARCHAR(191) NULL DEFAULT 'pending',
    `userId` VARCHAR(191) NULL,
    `paymentSessionId` TEXT NULL,
    `filesCount` INTEGER NULL DEFAULT 0,
    `paidAt` VARCHAR(40) NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    UNIQUE INDEX `orders_orderNumber_key`(`orderNumber`),
    INDEX `orders_customerEmail_idx`(`customerEmail`),
    INDEX `orders_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `order_items` (
    `id` VARCHAR(64) NOT NULL,
    `orderId` VARCHAR(191) NULL,
    `type` VARCHAR(191) NULL,
    `refId` VARCHAR(191) NULL,
    `name` VARCHAR(191) NULL,
    `price` DOUBLE NULL,
    `createdAt` VARCHAR(40) NULL,

    INDEX `order_items_orderId_idx`(`orderId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `payments` (
    `id` VARCHAR(64) NOT NULL,
    `orderId` VARCHAR(191) NULL,
    `orderNumber` VARCHAR(191) NULL,
    `amount` DOUBLE NULL,
    `currency` VARCHAR(191) NULL,
    `method` VARCHAR(191) NULL,
    `gateway` VARCHAR(191) NULL,
    `gatewayPaymentId` VARCHAR(191) NULL,
    `status` VARCHAR(191) NULL,
    `customerEmail` VARCHAR(191) NULL,
    `createdAt` VARCHAR(40) NULL,

    INDEX `payments_customerEmail_idx`(`customerEmail`),
    INDEX `payments_status_idx`(`status`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `invoices` (
    `id` VARCHAR(64) NOT NULL,
    `invoiceNumber` VARCHAR(191) NULL,
    `orderId` VARCHAR(191) NULL,
    `orderNumber` VARCHAR(191) NULL,
    `customerName` VARCHAR(191) NULL,
    `customerEmail` VARCHAR(191) NULL,
    `customerPhone` VARCHAR(191) NULL,
    `customerCompany` VARCHAR(191) NULL,
    `items` JSON NULL,
    `subtotal` DOUBLE NULL,
    `discount` DOUBLE NULL,
    `couponCode` VARCHAR(191) NULL,
    `taxRate` DOUBLE NULL,
    `tax` DOUBLE NULL,
    `total` DOUBLE NULL,
    `paymentId` VARCHAR(191) NULL,
    `paymentMethod` VARCHAR(191) NULL,
    `status` VARCHAR(191) NULL,
    `createdAt` VARCHAR(40) NULL,

    INDEX `invoices_customerEmail_idx`(`customerEmail`),
    INDEX `invoices_orderId_idx`(`orderId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `coupons` (
    `id` VARCHAR(64) NOT NULL,
    `code` VARCHAR(191) NULL,
    `type` VARCHAR(191) NULL,
    `value` DOUBLE NULL,
    `minOrder` DOUBLE NULL DEFAULT 0,
    `maxDiscount` DOUBLE NULL DEFAULT 0,
    `expiryDate` VARCHAR(40) NULL,
    `usageLimit` INTEGER NULL DEFAULT 0,
    `usedCount` INTEGER NULL DEFAULT 0,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    UNIQUE INDEX `coupons_code_key`(`code`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `leads` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(191) NULL,
    `email` VARCHAR(191) NULL,
    `phone` VARCHAR(191) NULL,
    `company` VARCHAR(191) NULL,
    `service` VARCHAR(191) NULL,
    `message` TEXT NULL,
    `source` VARCHAR(191) NULL,
    `ip` VARCHAR(191) NULL,
    `status` VARCHAR(191) NULL DEFAULT 'new',
    `notes` TEXT NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `blogs` (
    `id` VARCHAR(64) NOT NULL,
    `title` VARCHAR(191) NULL,
    `slug` VARCHAR(191) NULL,
    `excerpt` TEXT NULL,
    `content` LONGTEXT NULL,
    `image` TEXT NULL,
    `author` VARCHAR(191) NULL,
    `tags` JSON NULL,
    `status` VARCHAR(191) NULL DEFAULT 'draft',
    `publishedAt` VARCHAR(40) NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `portfolio` (
    `id` VARCHAR(64) NOT NULL,
    `title` VARCHAR(191) NULL,
    `category` VARCHAR(191) NULL,
    `description` TEXT NULL,
    `image` TEXT NULL,
    `link` TEXT NULL,
    `sortOrder` INTEGER NULL DEFAULT 0,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `testimonials` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(191) NULL,
    `role` VARCHAR(191) NULL,
    `content` TEXT NULL,
    `rating` INTEGER NULL DEFAULT 5,
    `sortOrder` INTEGER NULL DEFAULT 0,
    `avatar` TEXT NULL,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `support_tickets` (
    `id` VARCHAR(64) NOT NULL,
    `ticketNumber` VARCHAR(191) NULL,
    `userId` VARCHAR(191) NULL,
    `customerEmail` VARCHAR(191) NULL,
    `subject` TEXT NULL,
    `priority` VARCHAR(191) NULL DEFAULT 'medium',
    `status` VARCHAR(191) NULL DEFAULT 'open',
    `messages` JSON NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    INDEX `support_tickets_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `email_templates` (
    `id` VARCHAR(64) NOT NULL,
    `key` VARCHAR(191) NULL,
    `name` VARCHAR(191) NULL,
    `subject` TEXT NULL,
    `body` LONGTEXT NULL,
    `status` VARCHAR(191) NULL DEFAULT 'active',
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    UNIQUE INDEX `email_templates_key_key`(`key`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `website_settings` (
    `id` VARCHAR(64) NOT NULL,
    `key` VARCHAR(191) NULL,
    `siteName` VARCHAR(191) NULL,
    `logoText` VARCHAR(191) NULL,
    `tagline` VARCHAR(191) NULL,
    `colors` JSON NULL,
    `fonts` JSON NULL,
    `hero` JSON NULL,
    `services` JSON NULL,
    `features` JSON NULL,
    `whyChooseUs` JSON NULL,
    `process` JSON NULL,
    `faqs` JSON NULL,
    `contact` JSON NULL,
    `footer` JSON NULL,
    `seo` JSON NULL,
    `social` JSON NULL,
    `taxRate` DOUBLE NULL DEFAULT 10,
    `currency` VARCHAR(191) NULL DEFAULT 'USD',
    `currencySymbol` VARCHAR(191) NULL DEFAULT '$',
    `maintenanceMode` BOOLEAN NULL DEFAULT false,
    `analytics` JSON NULL,
    `createdAt` VARCHAR(40) NULL,
    `updatedAt` VARCHAR(40) NULL,

    UNIQUE INDEX `website_settings_key_key`(`key`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `notifications` (
    `id` VARCHAR(64) NOT NULL,
    `userId` VARCHAR(191) NULL,
    `title` VARCHAR(191) NULL,
    `message` TEXT NULL,
    `read` BOOLEAN NULL DEFAULT false,
    `createdAt` VARCHAR(40) NULL,

    INDEX `notifications_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `activity_logs` (
    `id` VARCHAR(64) NOT NULL,
    `actor` VARCHAR(191) NULL,
    `role` VARCHAR(191) NULL,
    `action` VARCHAR(191) NULL,
    `details` JSON NULL,
    `createdAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `newsletter` (
    `id` VARCHAR(64) NOT NULL,
    `email` VARCHAR(191) NULL,
    `ip` VARCHAR(191) NULL,
    `createdAt` VARCHAR(40) NULL,

    UNIQUE INDEX `newsletter_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `email_logs` (
    `id` VARCHAR(64) NOT NULL,
    `templateKey` VARCHAR(191) NULL,
    `to` VARCHAR(191) NULL,
    `subject` TEXT NULL,
    `body` LONGTEXT NULL,
    `mode` VARCHAR(191) NULL,
    `status` VARCHAR(191) NULL,
    `createdAt` VARCHAR(40) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `uploads` (
    `id` VARCHAR(64) NOT NULL,
    `userId` VARCHAR(191) NULL,
    `orderId` VARCHAR(191) NULL,
    `name` TEXT NULL,
    `type` VARCHAR(191) NULL,
    `category` VARCHAR(191) NULL,
    `data` LONGTEXT NULL,
    `storage` VARCHAR(191) NULL,
    `url` TEXT NULL,
    `createdAt` VARCHAR(40) NULL,

    INDEX `uploads_userId_idx`(`userId`),
    INDEX `uploads_orderId_idx`(`orderId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `messages` (
    `id` VARCHAR(64) NOT NULL,
    `userId` VARCHAR(191) NULL,
    `from` VARCHAR(191) NULL,
    `senderName` VARCHAR(191) NULL,
    `message` TEXT NULL,
    `read` BOOLEAN NULL DEFAULT false,
    `createdAt` VARCHAR(40) NULL,

    INDEX `messages_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `timeline_events` (
    `id` VARCHAR(64) NOT NULL,
    `orderId` VARCHAR(191) NULL,
    `title` VARCHAR(191) NULL,
    `description` TEXT NULL,
    `createdAt` VARCHAR(40) NULL,

    INDEX `timeline_events_orderId_idx`(`orderId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

