// Digital Dreams - API client & UI utilities
const API_BASE = 'api/index.php?r=';

async function api(route, opts = {}) {
  const method = opts.method || 'GET';
  const config = {
    method,
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
  };
  if (opts.body) config.body = JSON.stringify(opts.body);
  const res = await fetch(API_BASE + route, config);
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { error: text || 'Server error' }; }
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function $(sel, root = document) { return root.querySelector(sel); }
function $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

function toast(msg, type = 'info') {
  let wrap = $('.toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 4000);
}

function fmt(n) { return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function fmtDate(d) { try { return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return d; } }

// Reveal on scroll
function initReveal() {
  const els = $$('.reveal');
  if (!els.length || !('IntersectionObserver' in window)) { els.forEach(e => e.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.1 });
  els.forEach(e => io.observe(e));
}

// 3D Tilt effect
function initTilt() {
  $$('.tilt').forEach(el => {
    el.addEventListener('mousemove', (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      el.style.transform = `perspective(1000px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg) translateZ(0)`;
    });
    el.addEventListener('mouseleave', () => { el.style.transform = ''; });
  });
}

// Animated counter
function countUp(el, target, duration = 1500) {
  const start = 0;
  const startTime = performance.now();
  const suffix = String(target).replace(/[\d.]/g, '');
  const num = parseFloat(target);
  function tick(now) {
    const p = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = Math.floor(start + (num - start) * eased);
    el.textContent = val + suffix;
    if (p < 1) requestAnimationFrame(tick);
    else el.textContent = target;
  }
  requestAnimationFrame(tick);
}

function initCounters() {
  const els = $$('[data-count]');
  if (!('IntersectionObserver' in window)) { els.forEach(e => countUp(e, e.dataset.count)); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { countUp(e.target, e.target.dataset.count); io.unobserve(e.target); } });
  }, { threshold: 0.5 });
  els.forEach(e => io.observe(e));
}

// Modal helpers
function openModal(id) { const m = document.getElementById(id); if (m) m.classList.add('open'); }
function closeModal(id) { const m = document.getElementById(id); if (m) m.classList.remove('open'); }

document.addEventListener('DOMContentLoaded', () => {
  initReveal();
  initTilt();
  initCounters();
  // close modal on backdrop click
  $$('.modal-backdrop').forEach(m => {
    m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('open'); });
  });
});
