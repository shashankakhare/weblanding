<?php
// Digital Dreams Inc. - REST API router (PHP / shared hosting)
// All calls: api/index.php?r=ROUTE  (POST body = JSON)
declare(strict_types=1);
require __DIR__ . '/db.php';

try { ensure_seed(); } catch (Throwable $e) { fail('Database error: ' . $e->getMessage(), 500); }

$r = $_GET['r'] ?? 'health';
$M = $_SERVER['REQUEST_METHOD'];
$B = $M === 'GET' ? [] : body();
rate_limit('global', 240);

try {
switch (true) {

// ---------------- HEALTH ----------------
case $r === 'health':
  respond(['status' => 'ok', 'service' => 'Digital Dreams API (PHP)', 'time' => now()]);

// ---------------- PUBLIC CONTENT ----------------
case $r === 'public/content':
  respond([
    'settings' => t_one('website_settings', ['key' => 'main']),
    'packages' => t_find('packages', ['status' => 'active'], '`sortOrder` ASC'),
    'addons' => t_find('addons', ['status' => 'active'], '`sortOrder` ASC'),
    'testimonials' => t_find('testimonials', ['status' => 'active'], '`sortOrder` ASC'),
    'portfolio' => t_find('portfolio', ['status' => 'active'], '`sortOrder` ASC'),
    'blogs' => t_find('blogs', ['status' => 'published'], '`publishedAt` DESC', 6),
  ]);

// ---------------- AUTH ----------------
case $r === 'auth/register' && $M === 'POST': {
  rate_limit('auth', 15);
  $name = trim($B['name'] ?? ''); $email = strtolower(trim($B['email'] ?? '')); $pass = $B['password'] ?? '';
  if (!$name || !$email || !$pass) fail('Name, email and password are required');
  if (strlen($pass) < 6) fail('Password must be at least 6 characters');
  if (t_one('users', ['email' => $email])) fail('An account with this email already exists', 409);
  $u = ['id' => uuid(), 'name' => $name, 'email' => $email, 'password' => password_hash($pass, PASSWORD_BCRYPT), 'role' => 'customer', 'status' => 'active', 'createdAt' => now()];
  t_insert('users', $u);
  t_insert('customers', ['id' => uuid(), 'userId' => $u['id'], 'name' => $name, 'email' => $email, 'phone' => '', 'company' => '', 'totalOrders' => 0, 'totalSpent' => 0, 'createdAt' => now()]);
  $_SESSION['uid'] = $u['id'];
  send_email('welcome', $email, ['name' => $name, 'email' => $email, 'password' => '(the one you chose)']);
  audit($u, 'auth.register');
  respond(['user' => sanitize($u)]);
}

case $r === 'auth/login' && $M === 'POST': {
  rate_limit('auth', 15);
  $email = strtolower(trim($B['email'] ?? '')); $pass = $B['password'] ?? '';
  $u = t_one('users', ['email' => $email]);
  if (!$u || !password_verify($pass, $u['password'] ?? '')) fail('Invalid email or password', 401);
  if (($u['status'] ?? '') !== 'active') fail('Account is disabled', 403);
  $_SESSION['uid'] = $u['id'];
  audit($u, 'auth.login');
  respond(['user' => sanitize($u)]);
}

case $r === 'auth/logout':
  session_destroy();
  respond(['success' => true]);

case $r === 'auth/me': {
  $u = auth_user();
  if (!$u) fail('Not authenticated', 401);
  respond(['user' => sanitize($u)]);
}

case $r === 'auth/google':
  respond(['error' => 'Google OAuth is not configured yet. Add google_client_id/secret in config.php.', 'configured' => false], 501);

// ---------------- LEADS / NEWSLETTER ----------------
case $r === 'leads' && $M === 'POST': {
  rate_limit('leads', 10);
  if (empty($B['name']) || empty($B['email'])) fail('Name and email are required');
  $lead = ['id' => uuid(), 'name' => $B['name'], 'email' => $B['email'], 'phone' => $B['phone'] ?? '', 'company' => $B['company'] ?? '', 'service' => $B['service'] ?? '', 'message' => $B['message'] ?? '', 'source' => $B['source'] ?? 'contact_form', 'ip' => $_SERVER['REMOTE_ADDR'] ?? '', 'status' => 'new', 'notes' => '', 'createdAt' => now()];
  t_insert('leads', $lead);
  send_email('lead_received', $lead['email'], ['name' => $lead['name'], 'service' => $lead['service'] ?: 'our services']);
  send_email('admin_notification', 'admin@digitaldreams.com', ['event' => 'New lead', 'details' => "{$lead['name']} ({$lead['email']}) - {$lead['service']}: {$lead['message']}"]);
  notify('admin', 'New lead', "{$lead['name']} submitted an inquiry.");
  respond(['success' => true, 'leadId' => $lead['id']]);
}

case $r === 'newsletter' && $M === 'POST': {
  rate_limit('newsletter', 5);
  $email = strtolower(trim($B['email'] ?? ''));
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Valid email is required');
  if (t_one('newsletter', ['email' => $email])) respond(['success' => true, 'message' => 'Already subscribed']);
  t_insert('newsletter', ['id' => uuid(), 'email' => $email, 'ip' => $_SERVER['REMOTE_ADDR'] ?? '', 'createdAt' => now()]);
  respond(['success' => true]);
}

// ---------------- PRICING / COUPONS ----------------
case $r === 'pricing/calculate' && $M === 'POST': {
  $p = compute_pricing($B['packageId'] ?? '', $B['addonIds'] ?? [], $B['couponCode'] ?? '');
  if (isset($p['error'])) fail($p['error']);
  respond(['pricing' => $p]);
}

case $r === 'coupons/validate' && $M === 'POST': {
  if (empty($B['code']) || empty($B['packageId'])) fail('Coupon code and package are required');
  $p = compute_pricing($B['packageId'], $B['addonIds'] ?? [], $B['code']);
  if (isset($p['error'])) fail($p['error']);
  if ($p['couponError']) respond(['valid' => false, 'error' => $p['couponError']]);
  respond(['valid' => true, 'pricing' => $p]);
}

// ---------------- ORDERS ----------------
case $r === 'orders' && $M === 'POST': {
  rate_limit('orders', 10);
  $c = $B['customer'] ?? [];
  if (empty($B['packageId'])) fail('Package is required');
  if (empty($c['name']) || empty($c['email'])) fail('Customer name and email are required');
  $pricing = compute_pricing($B['packageId'], $B['addonIds'] ?? [], $B['couponCode'] ?? '');
  if (isset($pricing['error'])) fail($pricing['error']);
  $orderNumber = next_number('orders', 'ORD');
  $order = ['id' => uuid(), 'orderNumber' => $orderNumber, 'packageId' => $B['packageId'], 'addonIds' => $B['addonIds'] ?? [],
    'customerName' => $c['name'], 'customerEmail' => strtolower($c['email']), 'customerPhone' => $c['phone'] ?? '', 'customerCompany' => $c['company'] ?? '',
    'projectDetails' => $c['projectDetails'] ?? '', 'websiteUrl' => $c['websiteUrl'] ?? '', 'serviceType' => $c['serviceType'] ?? 'business',
    'pricing' => $pricing, 'status' => 'pending', 'filesCount' => 0, 'createdAt' => now(), 'updatedAt' => now()];
  t_insert('orders', $order);
  t_insert('order_items', ['id' => uuid(), 'orderId' => $order['id'], 'type' => 'package', 'refId' => $B['packageId'], 'name' => $pricing['package']['name'], 'price' => $pricing['package']['price'], 'createdAt' => now()]);
  foreach ($pricing['addons'] as $a) t_insert('order_items', ['id' => uuid(), 'orderId' => $order['id'], 'type' => 'addon', 'refId' => $a['id'], 'name' => $a['name'], 'price' => $a['price'], 'createdAt' => now()]);
  t_insert('timeline_events', ['id' => uuid(), 'orderId' => $order['id'], 'title' => 'Order placed', 'description' => "{$pricing['package']['name']} package ordered by {$c['name']}.", 'createdAt' => now()]);
  send_email('order_confirmation', $order['customerEmail'], ['name' => $c['name'], 'orderNumber' => $orderNumber, 'packageName' => $pricing['package']['name'], 'total' => '$' . $pricing['grandTotal']]);
  audit(['email' => $order['customerEmail'], 'role' => 'customer'], 'order.created', ['orderId' => $order['id']]);
  respond(['orderId' => $order['id'], 'orderNumber' => $orderNumber, 'pricing' => $pricing]);
}

case $r === 'orders/get': {
  $order = t_one('orders', ['id' => $_GET['id'] ?? '']);
  if (!$order) fail('Order not found', 404);
  respond(['order' => $order, 'invoice' => t_one('invoices', ['orderId' => $order['id']])]);
}

case $r === 'orders/uploads' && $M === 'POST': {
  rate_limit('uploads', 20);
  $order = t_one('orders', ['id' => $_GET['id'] ?? '']);
  if (!$order) fail('Order not found', 404);
  $files = $B['files'] ?? [];
  if (!$files) fail('No files provided');
  $stored = [];
  foreach (array_slice($files, 0, 10) as $f) {
    if (strlen($f['data'] ?? '') > 3000000) fail("File {$f['name']} exceeds 2MB limit");
    $doc = ['id' => uuid(), 'userId' => $order['userId'] ?? '', 'orderId' => $order['id'], 'name' => $f['name'], 'type' => $f['type'] ?? '', 'category' => $f['category'] ?? 'brand_asset', 'data' => $f['data'] ?? '', 'storage' => 'db_stub', 'url' => '', 'createdAt' => now()];
    t_insert('uploads', $doc);
    $stored[] = ['id' => $doc['id'], 'name' => $doc['name']];
  }
  t_update('orders', ['id' => $order['id']], ['filesCount' => ($order['filesCount'] ?? 0) + count($stored), 'updatedAt' => now()]);
  respond(['success' => true, 'files' => $stored]);
}

// ---------------- PAYMENTS ----------------
case $r === 'payments/session' && $M === 'POST': {
  global $CFG;
  $order = t_one('orders', ['id' => $B['orderId'] ?? '']);
  if (!$order) fail('Order not found', 404);
  if ($order['status'] === 'paid') fail('Order already paid', 409);
  if (empty($CFG['cashfree_app_id']) || empty($CFG['cashfree_secret_key'])) {
    t_update('orders', ['id' => $order['id']], ['paymentSessionId' => 'mock_session_' . $order['id'], 'updatedAt' => now()]);
    respond(['mock' => true, 'paymentSessionId' => 'mock_session_' . $order['id']]);
  }
  $base = $CFG['cashfree_env'] === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg';
  $payload = json_encode([
    'order_id' => $order['orderNumber'], 'order_amount' => $order['pricing']['grandTotal'], 'order_currency' => 'INR',
    'customer_details' => ['customer_id' => preg_replace('/[^a-zA-Z0-9]/', '_', $order['customerEmail']), 'customer_name' => $order['customerName'], 'customer_email' => $order['customerEmail'], 'customer_phone' => $order['customerPhone'] ?: '9999999999'],
    'order_meta' => ['return_url' => $CFG['base_url'] . '/order-success.html?orderId=' . $order['id'], 'notify_url' => $CFG['base_url'] . '/api/index.php?r=webhooks/cashfree'],
  ]);
  $ch = curl_init("$base/orders");
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'x-api-version: 2023-08-01', 'x-client-id: ' . $CFG['cashfree_app_id'], 'x-client-secret: ' . $CFG['cashfree_secret_key']]]);
  $res = json_decode((string)curl_exec($ch), true); curl_close($ch);
  if (empty($res['payment_session_id'])) fail('Payment gateway error: ' . ($res['message'] ?? 'unknown'), 502);
  t_update('orders', ['id' => $order['id']], ['paymentSessionId' => $res['payment_session_id'], 'updatedAt' => now()]);
  respond(['mock' => false, 'paymentSessionId' => $res['payment_session_id']]);
}

case $r === 'payments/mock-complete' && $M === 'POST': {
  $order = t_one('orders', ['id' => $B['orderId'] ?? '']);
  if (!$order) fail('Order not found', 404);
  respond(array_merge(['success' => true], finalize_order($order, 'mock (cashfree sandbox stub)', null)));
}

case $r === 'webhooks/cashfree' && $M === 'POST': {
  global $CFG;
  $raw = file_get_contents('php://input');
  $sig = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? ''; $ts = $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '';
  if (!empty($CFG['cashfree_secret_key']) && $sig && $ts) {
    $expected = base64_encode(hash_hmac('sha256', $ts . $raw, $CFG['cashfree_secret_key'], true));
    if (!hash_equals($expected, $sig)) fail('Invalid webhook signature', 401);
  }
  $p = json_decode($raw, true);
  $num = $p['data']['order']['order_id'] ?? null;
  if ($num && ($p['data']['payment']['payment_status'] ?? '') === 'SUCCESS') {
    $order = t_one('orders', ['orderNumber' => $num]);
    if ($order) finalize_order($order, $p['data']['payment']['payment_group'] ?? 'cashfree', (string)($p['data']['payment']['cf_payment_id'] ?? ''));
  }
  respond(['received' => true]);
}

case $r === 'invoices/get': {
  $inv = t_one('invoices', ['id' => $_GET['id'] ?? '']);
  if (!$inv) fail('Invoice not found', 404);
  $s = t_one('website_settings', ['key' => 'main']);
  respond(['invoice' => $inv, 'company' => ['name' => $s['siteName'], 'email' => $s['contact']['email'], 'address' => $s['contact']['address'], 'phone' => $s['contact']['phone']]]);
}

// ---------------- CUSTOMER ----------------
case str_starts_with($r, 'customer/'): {
  $u = require_auth();
  $own = ['$or' => [['userId' => $u['id']], ['customerEmail' => $u['email']]]];
  switch ($r) {
    case 'customer/overview': {
      $orders = t_find('orders', $own, '`createdAt` DESC');
      $invoices = t_find('invoices', ['customerEmail' => $u['email']], '`createdAt` DESC');
      $payments = t_find('payments', ['customerEmail' => $u['email']], '`createdAt` DESC');
      $tickets = t_find('support_tickets', ['userId' => $u['id']], '`createdAt` DESC');
      respond(['stats' => ['orders' => count($orders), 'invoices' => count($invoices),
        'totalSpent' => array_sum(array_column($payments, 'amount')),
        'openTickets' => count(array_filter($tickets, fn($t) => $t['status'] === 'open'))],
        'orders' => $orders, 'invoices' => $invoices, 'payments' => $payments, 'tickets' => $tickets,
        'notifications' => t_find('notifications', ['userId' => $u['id']], '`createdAt` DESC', 20)]);
    }
    case 'customer/orders': respond(['orders' => t_find('orders', $own, '`createdAt` DESC')]);
    case 'customer/invoices': respond(['invoices' => t_find('invoices', ['customerEmail' => $u['email']], '`createdAt` DESC')]);
    case 'customer/payments': respond(['payments' => t_find('payments', ['customerEmail' => $u['email']], '`createdAt` DESC')]);
    case 'customer/notifications': respond(['notifications' => t_find('notifications', ['userId' => $u['id']], '`createdAt` DESC', 50)]);
    case 'customer/notifications/read': t_update('notifications', ['userId' => $u['id']], ['read' => 1]); respond(['success' => true]);
    case 'customer/downloads': respond(['downloads' => t_find('uploads', ['userId' => $u['id'], 'category' => 'deliverable'], '`createdAt` DESC', 0, ['data'])]);
    case 'customer/messages':
      if ($M === 'POST') {
        if (empty($B['message'])) fail('Message is required');
        $msg = ['id' => uuid(), 'userId' => $u['id'], 'from' => 'customer', 'senderName' => $u['email'], 'message' => $B['message'], 'read' => false, 'createdAt' => now()];
        t_insert('messages', $msg);
        notify('admin', 'New message', $u['email'] . ': ' . mb_substr($B['message'], 0, 80));
        respond(['success' => true, 'message' => $msg]);
      }
      respond(['messages' => t_find('messages', ['userId' => $u['id']], '`createdAt` ASC')]);
    case 'customer/timeline': {
      $order = t_one('orders', ['id' => $_GET['orderId'] ?? '']);
      if (!$order || ($order['userId'] !== $u['id'] && $order['customerEmail'] !== $u['email'])) fail('Order not found', 404);
      respond(['order' => $order, 'events' => t_find('timeline_events', ['orderId' => $order['id']], '`createdAt` ASC')]);
    }
    case 'customer/tickets':
      if ($M === 'POST') {
        if (empty($B['subject']) || empty($B['message'])) fail('Subject and message are required');
        $tn = next_number('support_tickets', 'TKT');
        $t = ['id' => uuid(), 'ticketNumber' => $tn, 'userId' => $u['id'], 'customerEmail' => $u['email'], 'subject' => $B['subject'], 'priority' => $B['priority'] ?? 'medium', 'status' => 'open',
          'messages' => [['id' => uuid(), 'from' => 'customer', 'senderName' => $u['email'], 'message' => $B['message'], 'createdAt' => now()]], 'createdAt' => now(), 'updatedAt' => now()];
        t_insert('support_tickets', $t);
        send_email('support_ticket', $u['email'], ['name' => $u['email'], 'ticketNumber' => $tn, 'subject' => $B['subject']]);
        notify('admin', 'New support ticket', "$tn: {$B['subject']}");
        respond(['ticket' => $t]);
      }
      respond(['tickets' => t_find('support_tickets', ['userId' => $u['id']], '`createdAt` DESC')]);
    case 'customer/tickets/message': {
      $t = t_one('support_tickets', ['id' => $_GET['id'] ?? '', 'userId' => $u['id']]);
      if (!$t || empty($B['message'])) fail('Ticket not found or empty message', 404);
      $msgs = $t['messages'] ?? [];
      $msgs[] = ['id' => uuid(), 'from' => 'customer', 'senderName' => $u['email'], 'message' => $B['message'], 'createdAt' => now()];
      t_update('support_tickets', ['id' => $t['id']], ['messages' => $msgs, 'status' => 'open', 'updatedAt' => now()]);
      respond(['success' => true]);
    }
    case 'customer/profile': {
      t_update('users', ['id' => $u['id']], ['name' => $B['name'] ?? $u['name'], 'phone' => $B['phone'] ?? '', 'company' => $B['company'] ?? '', 'updatedAt' => now()]);
      t_update('customers', ['userId' => $u['id']], ['name' => $B['name'] ?? $u['name'], 'phone' => $B['phone'] ?? '', 'company' => $B['company'] ?? '']);
      respond(['user' => sanitize(t_one('users', ['id' => $u['id']]))]);
    }
    case 'customer/change-password': {
      if (strlen($B['newPassword'] ?? '') < 6) fail('New password must be at least 6 characters');
      if (!password_verify($B['currentPassword'] ?? '', $u['password'])) fail('Current password is incorrect', 401);
      t_update('users', ['id' => $u['id']], ['password' => password_hash($B['newPassword'], PASSWORD_BCRYPT), 'updatedAt' => now()]);
      audit($u, 'auth.password_changed');
      respond(['success' => true]);
    }
    case 'customer/uploads':
      if ($M === 'POST') {
        $files = $B['files'] ?? [];
        if (!$files) fail('No files provided');
        $stored = [];
        foreach (array_slice($files, 0, 10) as $f) {
          if (strlen($f['data'] ?? '') > 3000000) fail("File {$f['name']} exceeds 2MB limit");
          $doc = ['id' => uuid(), 'userId' => $u['id'], 'orderId' => $B['orderId'] ?? '', 'name' => $f['name'], 'type' => $f['type'] ?? '', 'category' => $f['category'] ?? 'asset', 'data' => $f['data'] ?? '', 'storage' => 'db_stub', 'url' => '', 'createdAt' => now()];
          t_insert('uploads', $doc);
          $stored[] = ['id' => $doc['id'], 'name' => $doc['name']];
        }
        respond(['success' => true, 'files' => $stored]);
      }
      respond(['uploads' => t_find('uploads', ['userId' => $u['id']], '`createdAt` DESC', 0, ['data'])]);
    case 'customer/uploads/file': {
      $f = t_one('uploads', ['id' => $_GET['id'] ?? '', 'userId' => $u['id']]);
      if (!$f) fail('File not found', 404);
      respond(['file' => $f]);
    }
  }
  fail('Route not found: ' . $r, 404);
}

// ---------------- ADMIN ----------------
case str_starts_with($r, 'admin/'): {
  $admin = require_admin();
  switch ($r) {
    case 'admin/stats': {
      $orders = t_find('orders', [], '`createdAt` DESC');
      $payments = t_find('payments', ['status' => 'success']);
      $revenue = array_sum(array_column($payments, 'amount'));
      $monthly = [];
      foreach ($payments as $p) { $m = substr($p['createdAt'] ?? '', 0, 7); $monthly[$m] = ($monthly[$m] ?? 0) + $p['amount']; }
      respond(['stats' => ['revenue' => $revenue, 'totalOrders' => count($orders),
        'paidOrders' => count(array_filter($orders, fn($o) => $o['status'] === 'paid')),
        'pendingOrders' => count(array_filter($orders, fn($o) => $o['status'] === 'pending')),
        'leads' => t_count('leads'), 'customers' => t_count('customers'), 'openTickets' => t_count('support_tickets', ['status' => 'open'])],
        'revenueByMonth' => array_map(fn($m, $a) => ['month' => $m, 'amount' => $a], array_keys($monthly), array_values($monthly)),
        'recentOrders' => array_slice($orders, 0, 10)]);
    }
    case 'admin/crud/list': {
      $col = $_GET['col'] ?? '';
      if (!in_array($col, TABLES)) fail('Unknown collection');
      $exclude = $col === 'uploads' ? ['data'] : ['password'];
      respond(['items' => t_find($col, [], '`createdAt` DESC', 500, $exclude)]);
    }
    case 'admin/crud/create': {
      $col = $_GET['col'] ?? '';
      if (!in_array($col, TABLES)) fail('Unknown collection');
      $doc = array_merge(['id' => uuid(), 'createdAt' => now()], $B);
      if ($col === 'users' && !empty($doc['password'])) $doc['password'] = password_hash($doc['password'], PASSWORD_BCRYPT);
      if ($col === 'coupons' && !empty($doc['code'])) { $doc['code'] = strtoupper($doc['code']); $doc['usedCount'] = $doc['usedCount'] ?? 0; }
      t_insert($col, $doc);
      audit($admin, "$col.created", ['id' => $doc['id']]);
      respond(['item' => sanitize($doc)]);
    }
    case 'admin/crud/update': {
      $col = $_GET['col'] ?? ''; $id = $_GET['id'] ?? '';
      if (!in_array($col, TABLES) || !$id) fail('Unknown collection or id');
      unset($B['id']);
      if ($col === 'users') { if (!empty($B['password'])) $B['password'] = password_hash($B['password'], PASSWORD_BCRYPT); else unset($B['password']); }
      if ($col === 'coupons' && !empty($B['code'])) $B['code'] = strtoupper($B['code']);
      $B['updatedAt'] = now();
      t_update($col, ['id' => $id], $B);
      audit($admin, "$col.updated", ['id' => $id]);
      respond(['item' => sanitize(t_one($col, ['id' => $id]))]);
    }
    case 'admin/crud/delete': {
      $col = $_GET['col'] ?? ''; $id = $_GET['id'] ?? '';
      if (!in_array($col, TABLES) || !$id) fail('Unknown collection or id');
      t_delete($col, ['id' => $id]);
      audit($admin, "$col.deleted", ['id' => $id]);
      respond(['success' => true]);
    }
    case 'admin/leads/export': {
      header('Content-Type: text/csv'); header('Content-Disposition: attachment; filename="leads.csv"');
      $out = fopen('php://output', 'w');
      fputcsv($out, ['Name','Email','Phone','Company','Service','Message','Source','IP','Status','Date']);
      foreach (t_find('leads', [], '`createdAt` DESC') as $l)
        fputcsv($out, [$l['name'],$l['email'],$l['phone'],$l['company'],$l['service'],$l['message'],$l['source'],$l['ip'],$l['status'],$l['createdAt']]);
      audit($admin, 'leads.export');
      exit;
    }
    case 'admin/settings': {
      unset($B['id'], $B['key']);
      $B['updatedAt'] = now();
      t_update('website_settings', ['key' => 'main'], $B);
      audit($admin, 'settings.updated');
      respond(['settings' => t_one('website_settings', ['key' => 'main'])]);
    }
    case 'admin/orders/status': {
      $order = t_one('orders', ['id' => $_GET['id'] ?? '']);
      if (!$order) fail('Order not found', 404);
      $status = $B['status'] ?? 'pending';
      t_update('orders', ['id' => $order['id']], ['status' => $status, 'updatedAt' => now()]);
      t_insert('timeline_events', ['id' => uuid(), 'orderId' => $order['id'], 'title' => 'Status: ' . str_replace('_', ' ', $status), 'description' => 'Order status updated to ' . str_replace('_', ' ', $status) . '.', 'createdAt' => now()]);
      if (!empty($order['userId'])) notify($order['userId'], 'Order update', "{$order['orderNumber']} is now " . str_replace('_', ' ', $status) . '.');
      $map = ['in_progress' => 'project_started', 'completed' => 'project_completed', 'refunded' => 'refund'];
      if (isset($map[$status])) send_email($map[$status], $order['customerEmail'], ['name' => $order['customerName'], 'orderNumber' => $order['orderNumber'], 'amount' => '$' . ($order['pricing']['grandTotal'] ?? '')]);
      audit($admin, 'order.status_changed', ['orderId' => $order['id'], 'status' => $status]);
      respond(['success' => true]);
    }
    case 'admin/tickets/reply': {
      $t = t_one('support_tickets', ['id' => $_GET['id'] ?? '']);
      if (!$t || empty($B['message'])) fail('Ticket not found or empty message', 404);
      $msgs = $t['messages'] ?? [];
      $msgs[] = ['id' => uuid(), 'from' => 'admin', 'senderName' => 'Support Team', 'message' => $B['message'], 'createdAt' => now()];
      t_update('support_tickets', ['id' => $t['id']], ['messages' => $msgs, 'status' => $B['status'] ?? 'answered', 'updatedAt' => now()]);
      notify($t['userId'], 'Support replied', "Reply on {$t['ticketNumber']}: " . mb_substr($B['message'], 0, 80));
      audit($admin, 'ticket.replied', ['ticketId' => $t['id']]);
      respond(['success' => true]);
    }
    case 'admin/messages/send': {
      if (empty($B['userId']) || empty($B['message'])) fail('userId and message are required');
      $msg = ['id' => uuid(), 'userId' => $B['userId'], 'from' => 'admin', 'senderName' => 'Digital Dreams Team', 'message' => $B['message'], 'read' => false, 'createdAt' => now()];
      t_insert('messages', $msg);
      notify($B['userId'], 'New message from team', mb_substr($B['message'], 0, 80));
      respond(['success' => true, 'message' => $msg]);
    }
    case 'admin/backup': {
      header('Content-Disposition: attachment; filename="digital-dreams-backup-' . time() . '.json"');
      $dump = [];
      foreach (TABLES as $t) $dump[$t] = t_find($t, [], '', 0, $t === 'uploads' ? ['data'] : ['password']);
      audit($admin, 'backup.exported');
      respond(['exportedAt' => now(), 'collections' => $dump]);
    }
    case 'admin/integrations': {
      global $CFG;
      respond([
        'cashfree' => ['configured' => !empty($CFG['cashfree_app_id']), 'env' => $CFG['cashfree_env']],
        'googleOAuth' => ['configured' => !empty($CFG['google_client_id'])],
        'smtp' => ['configured' => !empty($CFG['mail_enabled'])],
        'cloudinary' => ['configured' => false],
      ]);
    }
  }
  fail('Route not found: ' . $r, 404);
}

default:
  fail('Route not found: ' . $r, 404);
}
} catch (Throwable $e) {
  respond(['error' => 'Internal server error', 'detail' => $e->getMessage()], 500);
}

// ================= domain logic =================
function compute_pricing(string $packageId, array $addonIds, string $couponCode): array {
  $pkg = t_one('packages', ['id' => $packageId, 'status' => 'active']);
  if (!$pkg) return ['error' => 'Package not found'];
  if (!empty($pkg['contactSales'])) return ['error' => 'This package requires contacting sales'];
  $addons = $addonIds ? t_find('addons', ['id' => ['$in' => $addonIds], 'status' => 'active']) : [];
  $subtotal = (float)$pkg['price'] + array_sum(array_column($addons, 'price'));
  $discount = 0.0; $coupon = null; $couponError = null;
  if ($couponCode !== '') {
    $coupon = t_one('coupons', ['code' => strtoupper($couponCode), 'status' => 'active']);
    if (!$coupon) $couponError = 'Invalid coupon code';
    elseif (!empty($coupon['expiryDate']) && strtotime($coupon['expiryDate']) < time()) $couponError = 'Coupon has expired';
    elseif (!empty($coupon['usageLimit']) && $coupon['usedCount'] >= $coupon['usageLimit']) $couponError = 'Coupon usage limit reached';
    elseif (!empty($coupon['minOrder']) && $subtotal < $coupon['minOrder']) $couponError = "Minimum order of \${$coupon['minOrder']} required";
    else {
      $discount = $coupon['type'] === 'percentage' ? $subtotal * $coupon['value'] / 100 : (float)$coupon['value'];
      if (!empty($coupon['maxDiscount'])) $discount = min($discount, (float)$coupon['maxDiscount']);
      $discount = round($discount, 2);
    }
    if ($couponError) $coupon = null;
  }
  $s = t_one('website_settings', ['key' => 'main']);
  $taxRate = (float)($s['taxRate'] ?? 10);
  $taxable = max($subtotal - $discount, 0);
  $tax = round($taxable * $taxRate) / 100;
  return ['package' => $pkg, 'addons' => $addons, 'subtotal' => $subtotal, 'discount' => $discount,
    'coupon' => $coupon ? ['code' => $coupon['code'], 'type' => $coupon['type'], 'value' => $coupon['value']] : null,
    'couponError' => $couponError, 'taxRate' => $taxRate, 'tax' => $tax,
    'grandTotal' => round($taxable + $tax, 2), 'currency' => $s['currencySymbol'] ?? '$'];
}

function finalize_order(array $order, string $method, ?string $gatewayId): array {
  if ($order['status'] === 'paid') {
    return ['alreadyPaid' => true, 'invoice' => t_one('invoices', ['orderId' => $order['id']])];
  }
  t_update('orders', ['id' => $order['id']], ['status' => 'paid', 'paidAt' => now(), 'updatedAt' => now()]);
  $pr = $order['pricing'];
  $payment = ['id' => uuid(), 'orderId' => $order['id'], 'orderNumber' => $order['orderNumber'], 'amount' => $pr['grandTotal'], 'currency' => 'USD',
    'method' => $method, 'gateway' => 'cashfree', 'gatewayPaymentId' => $gatewayId ?: 'mock_pay_' . substr(uuid(), 0, 8), 'status' => 'success', 'customerEmail' => $order['customerEmail'], 'createdAt' => now()];
  t_insert('payments', $payment);
  $invoiceNumber = next_number('invoices', 'INV');
  $items = [['name' => $pr['package']['name'] . ' Package', 'price' => $pr['package']['price']]];
  foreach ($pr['addons'] as $a) $items[] = ['name' => 'Add-on: ' . $a['name'], 'price' => $a['price']];
  $invoice = ['id' => uuid(), 'invoiceNumber' => $invoiceNumber, 'orderId' => $order['id'], 'orderNumber' => $order['orderNumber'],
    'customerName' => $order['customerName'], 'customerEmail' => $order['customerEmail'], 'customerPhone' => $order['customerPhone'] ?? '', 'customerCompany' => $order['customerCompany'] ?? '',
    'items' => $items, 'subtotal' => $pr['subtotal'], 'discount' => $pr['discount'], 'couponCode' => $pr['coupon']['code'] ?? '', 'taxRate' => $pr['taxRate'], 'tax' => $pr['tax'], 'total' => $pr['grandTotal'],
    'paymentId' => $payment['gatewayPaymentId'], 'paymentMethod' => $method, 'status' => 'paid', 'createdAt' => now()];
  t_insert('invoices', $invoice);
  if (!empty($pr['coupon']['code'])) t_inc('coupons', ['code' => $pr['coupon']['code']], ['usedCount' => 1]);
  $user = t_one('users', ['email' => $order['customerEmail']]);
  $accountCreated = false;
  if (!$user) {
    $tmpPass = 'DD' . substr(bin2hex(random_bytes(4)), 0, 6) . '!';
    $user = ['id' => uuid(), 'name' => $order['customerName'], 'email' => $order['customerEmail'], 'password' => password_hash($tmpPass, PASSWORD_BCRYPT),
      'role' => 'customer', 'phone' => $order['customerPhone'] ?? '', 'company' => $order['customerCompany'] ?? '', 'status' => 'active', 'createdAt' => now()];
    t_insert('users', $user);
    t_insert('customers', ['id' => uuid(), 'userId' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'phone' => $user['phone'], 'company' => $user['company'], 'totalOrders' => 1, 'totalSpent' => $pr['grandTotal'], 'createdAt' => now()]);
    send_email('welcome', $order['customerEmail'], ['name' => $order['customerName'], 'email' => $order['customerEmail'], 'password' => $tmpPass]);
    $accountCreated = true;
  } else {
    t_inc('customers', ['email' => $order['customerEmail']], ['totalOrders' => 1, 'totalSpent' => $pr['grandTotal']]);
  }
  t_update('orders', ['id' => $order['id']], ['userId' => $user['id']]);
  t_update('uploads', ['orderId' => $order['id'], 'userId' => ''], ['userId' => $user['id']]);
  t_insert('timeline_events', ['id' => uuid(), 'orderId' => $order['id'], 'title' => 'Payment received', 'description' => "Payment of \${$pr['grandTotal']} confirmed. Project queued.", 'createdAt' => now()]);
  notify($user['id'], 'Payment received', "Payment of \${$pr['grandTotal']} received for {$order['orderNumber']}.");
  notify('admin', 'New paid order', "{$order['customerName']} paid \${$pr['grandTotal']} for {$order['orderNumber']}.");
  send_email('payment_success', $order['customerEmail'], ['name' => $order['customerName'], 'orderNumber' => $order['orderNumber'], 'total' => '$' . $pr['grandTotal']]);
  send_email('invoice_email', $order['customerEmail'], ['name' => $order['customerName'], 'invoiceNumber' => $invoiceNumber, 'orderNumber' => $order['orderNumber'], 'total' => '$' . $pr['grandTotal']]);
  send_email('admin_notification', 'admin@digitaldreams.com', ['event' => 'New paid order', 'details' => "{$order['customerName']} ({$order['customerEmail']}) paid \${$pr['grandTotal']} for {$order['orderNumber']}"]);
  audit(['email' => $order['customerEmail'], 'role' => 'customer'], 'order.paid', ['orderId' => $order['id'], 'amount' => $pr['grandTotal']]);
  return ['invoice' => $invoice, 'accountCreated' => $accountCreated, 'userId' => $user['id']];
}
