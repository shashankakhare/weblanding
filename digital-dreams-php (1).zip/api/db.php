<?php
// Digital Dreams - DB layer, helpers, auto-seed (PDO / MySQL)
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', '0');

$CFG = require __DIR__ . '/../config.php';

function db(): PDO {
  static $pdo = null;
  global $CFG;
  if ($pdo === null) {
    $pdo = new PDO(
      "mysql:host={$CFG['db_host']};dbname={$CFG['db_name']};charset=utf8mb4",
      $CFG['db_user'], $CFG['db_pass'],
      [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
  }
  return $pdo;
}

// ---- JSON / bool column maps (match schema) ----
const JSON_COLS = [
  'roles' => ['permissions'], 'packages' => ['features'], 'orders' => ['addonIds', 'pricing'],
  'invoices' => ['items'], 'blogs' => ['tags'], 'support_tickets' => ['messages'],
  'activity_logs' => ['details'],
  'website_settings' => ['colors','fonts','hero','services','features','whyChooseUs','process','faqs','contact','footer','seo','social','analytics'],
];
const BOOL_COLS = [
  'packages' => ['contactSales','popular'], 'addons' => ['popular','featured'],
  'website_settings' => ['maintenanceMode'], 'notifications' => ['read'], 'messages' => ['read'],
];
const TABLES = ['users','roles','customers','packages','package_features','addons','orders','order_items','payments','invoices','coupons','leads','blogs','portfolio','testimonials','support_tickets','email_templates','website_settings','notifications','activity_logs','newsletter','email_logs','uploads','messages','timeline_events'];

function row_out(string $t, ?array $r): ?array {
  if (!$r) return null;
  foreach (JSON_COLS[$t] ?? [] as $c) if (isset($r[$c]) && is_string($r[$c])) $r[$c] = json_decode($r[$c], true);
  foreach (BOOL_COLS[$t] ?? [] as $c) if (array_key_exists($c, $r)) $r[$c] = (bool)$r[$c];
  foreach (['price','amount','subtotal','discount','tax','total','taxRate','minOrder','maxDiscount','value','totalSpent'] as $c)
    if (isset($r[$c]) && is_numeric($r[$c])) $r[$c] = (float)$r[$c];
  foreach (['sortOrder','rating','usageLimit','usedCount','filesCount','totalOrders','step'] as $c)
    if (isset($r[$c]) && is_numeric($r[$c])) $r[$c] = (int)$r[$c];
  return $r;
}
function row_in(string $t, array $d): array {
  foreach (JSON_COLS[$t] ?? [] as $c) if (array_key_exists($c, $d) && !is_string($d[$c])) $d[$c] = json_encode($d[$c]);
  foreach (BOOL_COLS[$t] ?? [] as $c) if (array_key_exists($c, $d)) $d[$c] = $d[$c] ? 1 : 0;
  return $d;
}
function cols(string $t): array {
  static $cache = [];
  if (!isset($cache[$t])) {
    $cache[$t] = array_column(db()->query("SHOW COLUMNS FROM `$t`")->fetchAll(), 'Field');
  }
  return $cache[$t];
}
function clean(string $t, array $d): array {
  $allowed = cols($t);
  return array_intersect_key($d, array_flip($allowed));
}

// ---- generic table ops ----
function t_find(string $t, array $where = [], string $orderBy = '', int $limit = 0, array $exclude = []): array {
  [$sql, $params] = where_sql($where);
  $q = "SELECT * FROM `$t`" . $sql . ($orderBy ? " ORDER BY $orderBy" : '') . ($limit ? " LIMIT $limit" : '');
  $st = db()->prepare($q); $st->execute($params);
  $rows = array_map(fn($r) => row_out($t, $r), $st->fetchAll());
  if ($exclude) foreach ($rows as &$r) foreach ($exclude as $c) unset($r[$c]);
  return $rows;
}
function t_one(string $t, array $where): ?array {
  $rows = t_find($t, $where, '', 1);
  return $rows[0] ?? null;
}
function t_insert(string $t, array $d): void {
  $d = row_in($t, clean($t, $d));
  $ks = array_keys($d);
  $sql = "INSERT INTO `$t` (" . implode(',', array_map(fn($k) => "`$k`", $ks)) . ") VALUES (" . implode(',', array_fill(0, count($ks), '?')) . ")";
  db()->prepare($sql)->execute(array_values($d));
}
function t_update(string $t, array $where, array $d): void {
  if (!$d) return;
  $d = row_in($t, clean($t, $d));
  [$wsql, $wparams] = where_sql($where);
  $set = implode(',', array_map(fn($k) => "`$k`=?", array_keys($d)));
  db()->prepare("UPDATE `$t` SET $set" . $wsql)->execute(array_merge(array_values($d), $wparams));
}
function t_inc(string $t, array $where, array $incs): void {
  [$wsql, $wparams] = where_sql($where);
  $set = implode(',', array_map(fn($k) => "`$k`=COALESCE(`$k`,0)+?", array_keys($incs)));
  db()->prepare("UPDATE `$t` SET $set" . $wsql)->execute(array_merge(array_values($incs), $wparams));
}
function t_delete(string $t, array $where): void {
  [$wsql, $wparams] = where_sql($where);
  db()->prepare("DELETE FROM `$t`" . $wsql)->execute($wparams);
}
function t_count(string $t, array $where = []): int {
  [$wsql, $wparams] = where_sql($where);
  $st = db()->prepare("SELECT COUNT(*) c FROM `$t`" . $wsql); $st->execute($wparams);
  return (int)$st->fetch()['c'];
}
function where_sql(array $where): array {
  if (!$where) return ['', []];
  $parts = []; $params = [];
  foreach ($where as $k => $v) {
    if ($k === '$or') { // [['userId'=>x],['customerEmail'=>y]]
      $ors = [];
      foreach ($v as $sub) { [$s, $p] = where_sql($sub); $ors[] = '(' . substr($s, 7) . ')'; $params = array_merge($params, $p); }
      $parts[] = '(' . implode(' OR ', $ors) . ')';
    } elseif (is_array($v) && isset($v['$in'])) {
      $in = $v['$in'] ?: [''];
      $parts[] = "`$k` IN (" . implode(',', array_fill(0, count($in), '?')) . ')';
      $params = array_merge($params, $in);
    } else { $parts[] = "`$k`=?"; $params[] = $v; }
  }
  return [' WHERE ' . implode(' AND ', $parts), $params];
}

// ---- misc helpers ----
function uuid(): string {
  $d = random_bytes(16);
  $d[6] = chr(ord($d[6]) & 0x0f | 0x40); $d[8] = chr(ord($d[8]) & 0x3f | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}
function now(): string { return gmdate('Y-m-d\TH:i:s.v\Z'); }
function body(): array { return json_decode(file_get_contents('php://input'), true) ?: []; }
function respond($data, int $code = 200): never { http_response_code($code); echo json_encode($data); exit; }
function fail(string $msg, int $code = 400): never { respond(['error' => $msg], $code); }
function sanitize(?array $r): ?array { if ($r) { unset($r['password']); } return $r; }
function sanitize_all(array $rows): array { return array_map('sanitize', $rows); }

function rate_limit(string $key, int $limit, int $windowSec = 60): void {
  $f = sys_get_temp_dir() . '/dd_rl_' . md5($key . ($_SERVER['REMOTE_ADDR'] ?? ''));
  $raw = @file_get_contents($f);
  $d = json_decode(is_string($raw) ? $raw : '', true) ?: ['c' => 0, 'r' => time() + $windowSec];
  if (time() > $d['r']) $d = ['c' => 0, 'r' => time() + $windowSec];
  $d['c']++;
  @file_put_contents($f, json_encode($d));
  if ($d['c'] > $limit) fail('Too many requests', 429);
}

function auth_user(): ?array {
  if (empty($_SESSION['uid'])) return null;
  return t_one('users', ['id' => $_SESSION['uid']]);
}
function require_auth(): array { $u = auth_user(); if (!$u) fail('Not authenticated', 401); return $u; }
function require_admin(): array { $u = require_auth(); if (($u['role'] ?? '') !== 'admin') fail('Forbidden', 403); return $u; }

function audit(?array $actor, string $action, array $details = []): void {
  t_insert('activity_logs', ['id' => uuid(), 'actor' => $actor['email'] ?? 'system', 'role' => $actor['role'] ?? 'system', 'action' => $action, 'details' => $details, 'createdAt' => now()]);
}
function next_number(string $t, string $prefix): string {
  return $prefix . '-' . date('Y') . '-' . str_pad((string)(t_count($t) + 1), 4, '0', STR_PAD_LEFT);
}
function render_tpl(string $s, array $vars): string {
  return preg_replace_callback('/\{\{(\w+)\}\}/', fn($m) => (string)($vars[$m[1]] ?? $m[0]), $s);
}
function send_email(string $key, string $to, array $vars = []): void {
  global $CFG;
  $tpl = t_one('email_templates', ['key' => $key, 'status' => 'active']);
  if (!$tpl) return;
  $subject = render_tpl($tpl['subject'], $vars);
  $bodyTxt = render_tpl($tpl['body'], $vars);
  $sent = false;
  if (!empty($CFG['mail_enabled'])) {
    $headers = 'From: ' . $CFG['mail_from_name'] . ' <' . $CFG['mail_from'] . ">\r\nContent-Type: text/plain; charset=utf-8";
    $sent = @mail($to, $subject, $bodyTxt, $headers);
  }
  t_insert('email_logs', ['id' => uuid(), 'templateKey' => $key, 'to' => $to, 'subject' => $subject, 'body' => $bodyTxt, 'mode' => $sent ? 'mail' : 'stub', 'status' => $sent ? 'sent' : 'stubbed', 'createdAt' => now()]);
}
function notify(string $userId, string $title, string $message): void {
  t_insert('notifications', ['id' => uuid(), 'userId' => $userId, 'title' => $title, 'message' => $message, 'read' => false, 'createdAt' => now()]);
}

// One-shot migration: replace old external Unsplash URLs with bundled local paths
function migrate_image_urls(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    // Portfolio: map 6 unsplash photo IDs -> local files
    $map = [
      '1634084462412-b54873c0a56d' => 'assets/images/pf-1.jpg',
      '1648134859211-4a1b57575f4e' => 'assets/images/pf-2.jpg',
      '1531297484001-80022131f5a1' => 'assets/images/pf-3.jpg',
      '1603302576837-37561b2e2302' => 'assets/images/pf-4.jpg',
      '1637502875124-eb4a9843a2fa' => 'assets/images/pf-5.jpg',
      '1603985585179-3d71c35a537c' => 'assets/images/pf-6.jpg',
      '1611078489935-0cb964de46d6' => 'assets/images/hero.jpg',
    ];
    foreach (['portfolio', 'blogs'] as $t) {
      foreach (t_find($t, [], '', 0) as $r) {
        $img = $r['image'] ?? '';
        if (strpos($img, 'unsplash.com') === false) continue;
        $new = null;
        foreach ($map as $needle => $local) if (strpos($img, $needle) !== false) { $new = $local; break; }
        if (!$new) $new = 'assets/images/pf-1.jpg';
        t_update($t, ['id' => $r['id']], ['image' => $new]);
      }
    }
    // Hero image in website_settings
    $s = t_one('website_settings', ['key' => 'main']);
    if ($s && !empty($s['hero']['image']) && strpos($s['hero']['image'], 'unsplash.com') !== false) {
      $hero = $s['hero']; $hero['image'] = 'assets/images/hero.jpg';
      t_update('website_settings', ['key' => 'main'], ['hero' => $hero]);
    }
  } catch (Throwable $e) { /* silent - migration is best effort */ }
}

// ================= SEED =================
function ensure_seed(): void {
  migrate_image_urls();
  if (t_one('website_settings', ['key' => 'main'])) return;
  $n = now();
  t_insert('roles', ['id' => uuid(), 'name' => 'admin', 'permissions' => ['*'], 'createdAt' => $n]);
  t_insert('roles', ['id' => uuid(), 'name' => 'customer', 'permissions' => ['customer:*'], 'createdAt' => $n]);
  t_insert('users', ['id' => uuid(), 'name' => 'Admin', 'email' => 'admin@digitaldreams.com', 'password' => password_hash('admin123', PASSWORD_BCRYPT), 'role' => 'admin', 'status' => 'active', 'createdAt' => $n]);

  $pkgs = [
    ['starter','Starter',499.0,false,'Perfect for individuals and small startups getting online.','',false,1,['Up to 5 pages','Responsive mobile design','Contact form','Basic SEO setup','1 revision round','SSL certificate','7-day delivery']],
    ['business','Business',899.0,false,'Most popular for growing businesses that need more power.','Most Popular',true,2,['Up to 12 pages','Everything in Starter','Blog / CMS setup','Advanced SEO','Google Analytics integration','Social media integration','3 revision rounds','10-day delivery']],
    ['premium','Premium',1499.0,false,'For established brands that demand the very best.','Best Value',false,3,['Up to 25 pages','Everything in Business','Custom animations','E-commerce ready','Speed optimization','Priority support','Unlimited revisions','14-day delivery']],
    ['enterprise','Enterprise',null,true,'Custom solutions for large organizations. Tailored quote.','Custom',false,4,['Unlimited pages','Dedicated project manager','Custom integrations & APIs','SLA & priority support','Advanced security audit','Team training','Custom timeline']],
  ];
  foreach ($pkgs as $p) {
    $pid = uuid();
    t_insert('packages', ['id' => $pid, 'slug' => $p[0], 'name' => $p[1], 'price' => $p[2], 'contactSales' => $p[3], 'description' => $p[4], 'badge' => $p[5], 'popular' => $p[6], 'sortOrder' => $p[7], 'status' => 'active', 'features' => $p[8], 'createdAt' => $n]);
    foreach ($p[8] as $i => $f) t_insert('package_features', ['id' => uuid(), 'packageId' => $pid, 'feature' => $f, 'sortOrder' => $i + 1, 'createdAt' => $n]);
  }

  $addons = [
    ['Logo Design','Professional custom logo with 3 concepts and source files.',99,'Branding','Palette',1,true,true],
    ['Extra Page','One additional custom-designed page for your website.',49,'Development','FilePlus',2,false,false],
    ['SEO Boost','Advanced on-page SEO, schema markup and keyword optimization.',149,'Marketing','Search',3,true,false],
    ['Content Writing','Professional copywriting for up to 5 pages.',129,'Content','PenTool',4,false,false],
    ['E-commerce Module','Full online store with cart, checkout and up to 50 products.',299,'Development','ShoppingCart',5,false,true],
    ['6-Month Maintenance','Updates, backups and monitoring for 6 months.',199,'Support','Wrench',6,true,false],
    ['Speed Optimization','Core Web Vitals tuning, image optimization and caching.',89,'Development','Zap',7,false,false],
    ['Social Media Kit','Branded templates for Instagram, Facebook and LinkedIn.',119,'Branding','Share2',8,false,false],
  ];
  foreach ($addons as $a) t_insert('addons', ['id' => uuid(), 'name' => $a[0], 'description' => $a[1], 'price' => (float)$a[2], 'category' => $a[3], 'icon' => $a[4], 'sortOrder' => $a[5], 'popular' => $a[6], 'featured' => $a[7], 'image' => '', 'status' => 'active', 'createdAt' => $n]);

  $in30 = gmdate('Y-m-d\TH:i:s.v\Z', time() + 30 * 86400);
  $past = gmdate('Y-m-d\TH:i:s.v\Z', time() - 5 * 86400);
  t_insert('coupons', ['id' => uuid(), 'code' => 'WELCOME10', 'type' => 'percentage', 'value' => 10, 'minOrder' => 100, 'maxDiscount' => 200, 'expiryDate' => $in30, 'usageLimit' => 100, 'usedCount' => 0, 'status' => 'active', 'createdAt' => $n]);
  t_insert('coupons', ['id' => uuid(), 'code' => 'FLAT50', 'type' => 'flat', 'value' => 50, 'minOrder' => 499, 'maxDiscount' => 50, 'expiryDate' => $in30, 'usageLimit' => 50, 'usedCount' => 0, 'status' => 'active', 'createdAt' => $n]);
  t_insert('coupons', ['id' => uuid(), 'code' => 'EXPIRED20', 'type' => 'percentage', 'value' => 20, 'minOrder' => 0, 'maxDiscount' => 500, 'expiryDate' => $past, 'usageLimit' => 10, 'usedCount' => 0, 'status' => 'active', 'createdAt' => $n]);

  $tpls = [
    ['lead_received','Lead Received','Thanks for reaching out, {{name}}!',"Hi {{name}},\n\nThank you for contacting Digital Dreams Inc. Our team has received your inquiry about {{service}} and will get back to you within 24 hours.\n\nBest,\nDigital Dreams Team"],
    ['order_confirmation','Order Confirmation','Order {{orderNumber}} confirmed - Digital Dreams Inc.',"Hi {{name}},\n\nYour order {{orderNumber}} for the {{packageName}} package has been received.\n\nTotal: {{total}}\n\nWe will begin work as soon as payment is confirmed.\n\nBest,\nDigital Dreams Team"],
    ['payment_success','Payment Success','Payment received for {{orderNumber}}',"Hi {{name}},\n\nWe have received your payment of {{total}} for order {{orderNumber}}. Your project is now in our queue!\n\nBest,\nDigital Dreams Team"],
    ['invoice_email','Invoice','Your invoice {{invoiceNumber}} from Digital Dreams Inc.',"Hi {{name}},\n\nPlease find your invoice {{invoiceNumber}} for order {{orderNumber}}.\nAmount: {{total}}\n\nYou can download it anytime from your dashboard.\n\nBest,\nDigital Dreams Team"],
    ['welcome','Welcome / Account Created','Welcome to Digital Dreams Inc., {{name}}!',"Hi {{name}},\n\nYour customer account has been created.\nEmail: {{email}}\nTemporary password: {{password}}\n\nPlease log in and change your password.\n\nBest,\nDigital Dreams Team"],
    ['password_reset','Password Reset','Reset your password',"Hi {{name}},\n\nClick the link below to reset your password:\n{{resetLink}}\n\nIf you did not request this, ignore this email."],
    ['support_ticket','Support Ticket','Ticket {{ticketNumber}} received',"Hi {{name}},\n\nWe received your support ticket \"{{subject}}\" ({{ticketNumber}}). Our team will respond shortly.\n\nBest,\nDigital Dreams Support"],
    ['project_started','Project Started','Your project has started!',"Hi {{name}},\n\nGreat news! Work on your project ({{orderNumber}}) has officially started. Track progress in your dashboard.\n\nBest,\nDigital Dreams Team"],
    ['project_completed','Project Completed','Your project is complete!',"Hi {{name}},\n\nYour project ({{orderNumber}}) is complete! Deliverables are available in your dashboard downloads.\n\nThank you for choosing Digital Dreams Inc."],
    ['refund','Refund Processed','Refund processed for {{orderNumber}}',"Hi {{name}},\n\nA refund of {{amount}} has been processed for order {{orderNumber}}. It may take 5-7 business days to reflect.\n\nBest,\nDigital Dreams Team"],
    ['admin_notification','Admin Notification','[Admin] {{event}}',"Admin alert:\n\n{{details}}\n\n- Digital Dreams System"],
  ];
  foreach ($tpls as $t) t_insert('email_templates', ['id' => uuid(), 'key' => $t[0], 'name' => $t[1], 'subject' => $t[2], 'body' => $t[3], 'status' => 'active', 'createdAt' => $n]);

  $heroImg = 'assets/images/hero.jpg';
  $pf = ['assets/images/pf-1.jpg','assets/images/pf-2.jpg','assets/images/pf-3.jpg','assets/images/pf-4.jpg','assets/images/pf-5.jpg','assets/images/pf-6.jpg'];

  t_insert('website_settings', [
    'id' => uuid(), 'key' => 'main', 'siteName' => 'Digital Dreams Inc.', 'logoText' => 'Digital Dreams', 'tagline' => 'Websites that build your business',
    'colors' => ['primary' => '#6366f1', 'accent' => '#a855f7'], 'fonts' => ['heading' => 'Inter', 'body' => 'Inter'],
    'hero' => [
      'badge' => 'Trusted by 250+ businesses worldwide',
      'title' => 'We Build Websites That Build Your Business',
      'subtitle' => 'Digital Dreams Inc. crafts premium, high-converting websites for businesses and professionals. From stunning portfolios to full e-commerce platforms - delivered fast, built to last.',
      'ctaPrimary' => 'Get Started', 'ctaSecondary' => 'View Pricing', 'image' => $heroImg,
      'stats' => [['value' => '250+', 'label' => 'Projects Delivered'], ['value' => '98%', 'label' => 'Client Satisfaction'], ['value' => '12+', 'label' => 'Years Experience'], ['value' => '40+', 'label' => 'Team Experts']],
    ],
    'services' => [
      ['icon' => 'globe', 'title' => 'Business Websites', 'desc' => 'Professional corporate websites that establish credibility and convert visitors into customers.'],
      ['icon' => 'user', 'title' => 'Portfolio Sites', 'desc' => 'Stunning personal portfolios for creatives, freelancers and professionals to showcase their work.'],
      ['icon' => 'cart', 'title' => 'E-commerce Stores', 'desc' => 'Full-featured online stores with secure checkout, inventory and payment integration.'],
      ['icon' => 'rocket', 'title' => 'Landing Pages', 'desc' => 'High-converting landing pages engineered for campaigns, launches and lead generation.'],
      ['icon' => 'search', 'title' => 'SEO Optimization', 'desc' => 'Technical and on-page SEO that gets you found on Google and drives organic traffic.'],
      ['icon' => 'wrench', 'title' => 'Maintenance & Support', 'desc' => 'Ongoing updates, backups, security monitoring and priority support plans.'],
    ],
    'features' => [
      ['icon' => 'phone', 'title' => 'Fully Responsive', 'desc' => 'Pixel-perfect on every device - mobile, tablet and desktop.'],
      ['icon' => 'zap', 'title' => 'Blazing Fast', 'desc' => 'Optimized for Core Web Vitals with sub-second load times.'],
      ['icon' => 'search', 'title' => 'SEO Ready', 'desc' => 'Semantic markup, meta tags and schema built in from day one.'],
      ['icon' => 'shield', 'title' => 'Secure by Default', 'desc' => 'SSL, security headers and hardened infrastructure.'],
      ['icon' => 'brush', 'title' => 'Custom Design', 'desc' => 'No templates - every site is designed for your brand.'],
      ['icon' => 'chart', 'title' => 'Analytics Built-in', 'desc' => 'GA4 and conversion tracking configured for you.'],
      ['icon' => 'refresh', 'title' => 'Easy Updates', 'desc' => 'CMS-powered content you can edit without code.'],
      ['icon' => 'headset', 'title' => 'Real Support', 'desc' => 'Humans, not bots. Support that actually responds.'],
    ],
    'whyChooseUs' => [
      ['icon' => 'award', 'title' => '12+ Years of Craft', 'desc' => 'Over a decade of building digital products that perform.'],
      ['icon' => 'clock', 'title' => 'On-Time Delivery', 'desc' => 'Guaranteed timelines with milestone-based delivery.'],
      ['icon' => 'dollar', 'title' => 'Transparent Pricing', 'desc' => 'Fixed prices, no hidden fees, no surprises.'],
      ['icon' => 'users', 'title' => 'Dedicated Team', 'desc' => 'A designer, developer and PM assigned to every project.'],
      ['icon' => 'repeat', 'title' => 'Unlimited Revisions', 'desc' => 'On Premium plans, we iterate until you love it.'],
      ['icon' => 'lifebuoy', 'title' => 'Post-Launch Care', 'desc' => '30 days of free support after every launch.'],
    ],
    'process' => [
      ['step' => 1, 'title' => 'Discovery', 'desc' => 'We learn your business, goals and audience in a kickoff call.'],
      ['step' => 2, 'title' => 'Strategy', 'desc' => 'Sitemap, wireframes and content plan tailored to conversions.'],
      ['step' => 3, 'title' => 'Design', 'desc' => 'Premium UI design with your brand, reviewed and refined.'],
      ['step' => 4, 'title' => 'Development', 'desc' => 'Clean, fast, secure code built on modern frameworks.'],
      ['step' => 5, 'title' => 'Review & QA', 'desc' => 'Cross-device testing, speed tuning and your final approval.'],
      ['step' => 6, 'title' => 'Launch & Support', 'desc' => 'We deploy, monitor and support you after go-live.'],
    ],
    'faqs' => [
      ['q' => 'How long does it take to build my website?', 'a' => 'Starter sites ship in about 7 days, Business in 10 days, and Premium in 14 days. Enterprise timelines are custom-scoped.'],
      ['q' => 'What do I need to provide before you start?', 'a' => 'Your logo, brand assets, photos and any content you have. You can upload everything during checkout or from your dashboard afterwards.'],
      ['q' => 'Can I edit the website myself after launch?', 'a' => 'Yes - Business and Premium plans include a CMS so you can edit text, images and blog posts without touching code.'],
      ['q' => 'Do you offer refunds?', 'a' => 'We offer a full refund within 7 days if work has not started, and prorated refunds thereafter per our refund policy.'],
      ['q' => 'Which payment methods do you accept?', 'a' => 'We accept cards, UPI, netbanking and wallets via our secure Cashfree payment gateway.'],
      ['q' => 'Will my website work on mobile?', 'a' => 'Absolutely. Every site we build is fully responsive and tested across phones, tablets and desktops.'],
      ['q' => 'Do you provide hosting and domain?', 'a' => 'We can deploy to your hosting or recommend managed options. Domain and hosting fees are billed separately at cost.'],
      ['q' => 'What happens after I pay?', 'a' => 'You get an instant invoice and a customer account. Our team contacts you within 24 hours to kick off your project.'],
    ],
    'contact' => ['email' => 'hello@digitaldreams.com', 'phone' => '+1 (555) 123-4567', 'address' => '100 Innovation Drive, San Francisco, CA 94107', 'whatsapp' => '15551234567'],
    'footer' => ['about' => 'Digital Dreams Inc. is a full-service web design agency crafting premium websites, stores and portfolios for ambitious brands worldwide.', 'copyright' => '\u00a9 ' . date('Y') . ' Digital Dreams Inc. All rights reserved.'],
    'seo' => ['title' => 'Digital Dreams Inc. - Premium Website Design Agency', 'description' => 'Premium business websites, portfolios and e-commerce stores. Fixed pricing from $499, delivered in days.', 'keywords' => 'website design, web development, portfolio website, business website, ecommerce'],
    'social' => ['twitter' => 'https://twitter.com/digitaldreams', 'facebook' => 'https://facebook.com/digitaldreams', 'instagram' => 'https://instagram.com/digitaldreams', 'linkedin' => 'https://linkedin.com/company/digitaldreams'],
    'taxRate' => 10, 'currency' => 'USD', 'currencySymbol' => '$', 'maintenanceMode' => false,
    'analytics' => ['ga4Id' => '', 'metaPixelId' => '', 'searchConsoleCode' => ''],
    'createdAt' => $n,
  ]);

  $tst = [
    ['Sarah Mitchell','Founder, Bloom Boutique','Digital Dreams rebuilt our store and sales jumped 40% in the first month. The team was fast, communicative and genuinely cared about our results.',5,1],
    ['James Carter','CEO, Carter Consulting','The most professional web agency I have worked with. Fixed pricing, zero surprises, and the site was delivered two days early.',5,2],
    ['Priya Sharma','Photographer','My portfolio site is stunning. Clients constantly compliment it, and bookings have doubled since launch.',5,3],
    ['Michael Torres','COO, Nexline Logistics','From discovery to launch, the process was seamless. Their live pricing calculator made budgeting effortless.',4,4],
    ['Emma Wilson','Owner, Wilson Fitness','They handled everything - design, content, SEO. I just uploaded my logo and photos at checkout. Incredible experience.',5,5],
    ['David Kim','Founder, Kim & Co Legal','Premium quality at honest prices. The dashboard makes tracking my project and invoices effortless.',5,6],
  ];
  foreach ($tst as $t) t_insert('testimonials', ['id' => uuid(), 'name' => $t[0], 'role' => $t[1], 'content' => $t[2], 'rating' => $t[3], 'sortOrder' => $t[4], 'avatar' => '', 'status' => 'active', 'createdAt' => $n]);

  $ports = [['Nova Web Studio','Business','A modern web builder platform with live editing and premium UI.'],['FlowDesk Workflows','SaaS','Dark-mode SaaS marketing site with animated workflow demos.'],['Meridian Consulting','Corporate','Corporate consulting site with lead-gen focus and booking.'],['Pulse Audio Store','E-commerce','E-commerce store for audio gear with rich product pages.'],['Atelier Portfolio','Portfolio','Minimal photography portfolio with immersive galleries.'],['Darkline Digital','Agency','Multi-device agency showcase with bold dark aesthetics.']];
  foreach ($ports as $i => $p) t_insert('portfolio', ['id' => uuid(), 'title' => $p[0], 'category' => $p[1], 'description' => $p[2], 'image' => $pf[$i], 'link' => '#', 'sortOrder' => $i + 1, 'status' => 'active', 'createdAt' => $n]);

  $blogs = [['7 Signs Your Business Website Needs a Redesign','signs-website-needs-redesign','Is your website costing you customers? Here are the warning signs.'],['How Much Should a Business Website Cost in 2025?','website-cost-2025','A transparent breakdown of website pricing and what you actually get.'],['SEO Basics Every Small Business Owner Should Know','seo-basics-small-business','Simple, actionable SEO steps that move the needle.']];
  foreach ($blogs as $i => $b) t_insert('blogs', ['id' => uuid(), 'title' => $b[0], 'slug' => $b[1], 'excerpt' => $b[2], 'content' => $b[2] . ' (Full article content.)', 'image' => $pf[$i], 'author' => 'Digital Dreams Team', 'tags' => ['web design'], 'status' => 'published', 'publishedAt' => $n, 'createdAt' => $n]);
}
